import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../mock/mock_repository.dart';
import '../models/goal.dart';

final goalProvider =
    StateNotifierProvider<GoalNotifier, List<Goal>>(
  (ref) => GoalNotifier(),
);

class GoalNotifier extends StateNotifier<List<Goal>> {
  GoalNotifier() : super([]) {
    loadGoals();
  }

  Future<void> loadGoals() async {
    state = await MockRepository.loadGoals();
  }

  Future<void> refresh() async {
    state = await MockRepository.loadGoals();
  }

  Future<void> addGoal(Goal goal) async {
    final list = [...state];
    list.add(goal);
    state = list;
  }

  Future<void> removeGoal(String id) async {
    state = state.where((e) => e.id != id).toList();
  }

  Future<void> updateGoal(Goal goal) async {
    state = [
      for (final item in state)
        if (item.id == goal.id) goal else item,
    ];
  }

  Goal? findById(String id) {
    try {
      return state.firstWhere((e) => e.id == id);
    } catch (_) {
      return null;
    }
  }

  List<Goal> get completed =>
      state.where((e) => e.progress >= 1).toList();

  List<Goal> get running =>
      state.where((e) => e.progress < 1).toList();

  double get totalProgress {
    if (state.isEmpty) return 0;

    double total = 0;

    for (final goal in state) {
      total += goal.progress;
    }

    return total / state.length;
  }
}
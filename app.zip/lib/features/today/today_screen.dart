import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../life_engine/providers/goal_provider.dart';

import 'widgets/greeting_card.dart';
import 'widgets/life_countdown_card.dart';
import 'widgets/goal_card.dart';
import 'widgets/quote_card.dart';
import 'widgets/progress_card.dart';
import 'widgets/coach_card.dart';

class TodayScreen extends ConsumerWidget {
  const TodayScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 页面初始化时读取 Goal 数据
    ref.watch(goalProvider);

    return Scaffold(
      backgroundColor: const Color(0xffF5F7FA),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        centerTitle: false,
        title: const Text(
          "今日",
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            await ref.read(goalProvider.notifier).refresh();
          },
          child: const SingleChildScrollView(
            physics: AlwaysScrollableScrollPhysics(),
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [

                GreetingCard(),

                SizedBox(height: 16),

                LifeCountdownCard(),

                SizedBox(height: 16),

                GoalCard(),

                SizedBox(height: 16),

                ProgressCard(),

                SizedBox(height: 16),

                QuoteCard(),

                SizedBox(height: 16),

                CoachCard(),

                SizedBox(height: 32),
              ],
            ),
          ),
        ),
      ),
    );
  }
}